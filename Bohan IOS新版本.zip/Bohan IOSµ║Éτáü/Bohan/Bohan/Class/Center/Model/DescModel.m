//
//  DescModel.m
//  Bohan
//
//  Created by Yang Lin on 2018/2/7.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import "DescModel.h"

@implementation DescModel

+ (NSDictionary *)modelCustomPropertyMapper {
    return @{@"cID" : @"CID",
             @"cDesc" : @"CDesc"};
}
@end
