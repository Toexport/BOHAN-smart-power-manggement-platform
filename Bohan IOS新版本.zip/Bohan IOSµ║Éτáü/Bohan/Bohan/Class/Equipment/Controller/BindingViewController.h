//
//  BindingViewController.h
//  Bohan
//
//  Created by Yang Lin on 2017/12/31.
//  Copyright © 2017年 Bohan. All rights reserved.
//

#import "BaseViewController.h"
#import "DeviceModel.h"
@interface BindingViewController : BaseViewController
@end
