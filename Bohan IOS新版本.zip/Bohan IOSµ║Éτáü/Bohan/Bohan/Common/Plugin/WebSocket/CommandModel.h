//
//  CommandModel.h
//  Bohan
//
//  Created by Yang Lin on 2018/1/12.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface CommandModel : NSObject

@property (nonatomic, copy)NSString *deviceNo;
@property (nonatomic, copy)NSString *command;
@property (nonatomic, copy)NSString *content;

@end
