//
//  UITextField+NoCopyPaste.h
//  UFA
//
//  Created by YangLin on 2018/1/3.
//  Copyright © 2018年 UFA. All rights reserved.
//

@interface UITextField (NoCopyPaste)

@property (nonatomic, assign) BOOL noCopyPaste;//是否禁用复制、粘贴按钮操作
@end
