//
//  UIViewController+Utils.h
//  UFA
//
//  Created by YangLin on 2017/12/18.
//  Copyright © 2017年 UFA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIViewController (Utils)

@end
