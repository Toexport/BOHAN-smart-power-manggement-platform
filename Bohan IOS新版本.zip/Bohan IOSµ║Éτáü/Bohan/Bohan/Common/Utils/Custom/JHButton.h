//
//  JHButton.h
//  UFA
//
//  Created by mac on 2017/7/7.
//  Copyright © 2017年 UFA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface JHButton : UIButton

@end
