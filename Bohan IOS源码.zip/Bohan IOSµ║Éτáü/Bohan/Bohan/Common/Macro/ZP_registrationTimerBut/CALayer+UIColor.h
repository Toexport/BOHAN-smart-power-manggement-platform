//
//  CALayer+UIColor.h
//  VINEYARDS
//
//  Created by APPLE on 16/9/5.
//  Copyright © 2016年 VINEYARDS. All rights reserved.
//

#import <QuartzCore/QuartzCore.h>
#import <UIKit/UIKit.h>

@interface CALayer (UIColor)

@property (nonatomic,strong) UIColor *borderColorFromUIColor;

@end
