//
//  ESPGuideCode.h
//  EspTouchDemo
//
//  Created by 白 桦 on 4/9/15.
//  Copyright (c) 2015 白 桦. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ESPGuideCode : NSObject

- (NSData *) getU16s;

@end
