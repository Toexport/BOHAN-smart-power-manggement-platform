//
//  AppDelegate+Configure.h
//  UFA
//
//  Created by YangLin on 2017/7/7.
//  Copyright © 2017年 UFA. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (Configure)

/**
 配置navigationbar、tabbar样式
 */
- (void)appearance;
@end
