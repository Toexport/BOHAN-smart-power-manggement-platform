//
//  UIButton+Disable.h
//  Wordaily
//
//  Created by YangLin on 16/3/22.
//  Copyright © 2016年 YangLin. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIButton (Disable)


- (void)disable;
- (void)enable;

@end
