//
//  UIViewController+Utils.m
//  UFA
//
//  Created by YangLin on 2017/12/18.
//  Copyright © 2017年 UFA. All rights reserved.
//

#import "UIViewController+Utils.h"

@implementation UIViewController (Utils)


- (void)showMessage:(NSString *)message
{
    
}

- (void)showError:(NSError *)error
{
    
}
@end
