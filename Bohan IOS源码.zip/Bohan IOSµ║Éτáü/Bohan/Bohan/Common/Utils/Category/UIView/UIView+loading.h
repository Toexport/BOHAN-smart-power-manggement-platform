//
//  UIView+loading.h
//  UFA
//
//  Created by YangLin on 2017/7/1.
//  Copyright © 2017年 UFA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (loading)


//开始加载试图
- (void)startLoading;

//结束加载试图
- (void)stopLoading;
@end
