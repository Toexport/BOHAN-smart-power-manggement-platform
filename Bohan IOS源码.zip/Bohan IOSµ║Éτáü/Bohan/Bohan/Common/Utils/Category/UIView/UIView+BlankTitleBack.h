//
//  UIView+BlankTitleBack.h
//  UFA
//
//  Created by YangLin on 2017/10/19.
//  Copyright © 2017年 UFA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (BlankTitleBack)

@end
