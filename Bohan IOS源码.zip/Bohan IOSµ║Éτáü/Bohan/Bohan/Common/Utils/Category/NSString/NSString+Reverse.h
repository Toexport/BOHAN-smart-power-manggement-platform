//
//  NSString+Reverse.h
//  UFA
//
//  Created by YangLin on 2017/7/22.
//  Copyright © 2017年 UFA. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (Reverse)


- (NSString *)reverse;

+ (NSString *)reverseString:(NSString *)string;
@end
