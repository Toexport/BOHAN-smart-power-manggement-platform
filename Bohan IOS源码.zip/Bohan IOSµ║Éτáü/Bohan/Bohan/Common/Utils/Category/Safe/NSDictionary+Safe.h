//
//  NSDictionary+Safe.h
//  UFA
//
//  Created by YangLin on 2018/1/29.
//  Copyright © 2018年 UFA. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "NSObject+Safe.h"
@interface NSDictionary (Safe)

@end
