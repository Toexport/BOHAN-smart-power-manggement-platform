//
//  CountDownButton.h
//  UFA
//
//  Created by YangLin on 2017/8/16.
//  Copyright © 2017年 UFA. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CountDownButton : UIButton

- (void)startTime;
@end
