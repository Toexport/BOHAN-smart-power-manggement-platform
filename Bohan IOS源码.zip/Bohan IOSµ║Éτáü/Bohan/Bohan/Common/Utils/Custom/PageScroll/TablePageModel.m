
//
//  TablePageModel.m
//  UFA
//
//  Created by YangLin on 2017/7/26.
//  Copyright © 2017年 UFA. All rights reserved.
//

#import "TablePageModel.h"

@implementation TablePageModel

@end
