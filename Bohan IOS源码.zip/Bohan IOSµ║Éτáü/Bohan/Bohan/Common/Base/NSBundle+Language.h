//
//  NSBundle+Language.h
//  DDAYGO
//
//  Created by Summer on 2017/11/6.
//  Copyright © 2017年 Summer. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSBundle (Language)
+ (void)setLanguage:(NSString *)language;
@end
