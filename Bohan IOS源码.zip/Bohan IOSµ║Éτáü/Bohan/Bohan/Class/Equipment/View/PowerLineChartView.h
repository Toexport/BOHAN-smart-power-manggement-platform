//
//  PowerLineChartView.h
//  Bohan
//
//  Created by Yang Lin on 2018/2/4.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PowerLineChartView : UIView
@property (nonatomic, copy) NSArray *datas;
@property (nonatomic, copy)NSString *title;

@end
