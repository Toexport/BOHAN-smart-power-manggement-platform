//
//  ContentTableView.h
//  UFA
//
//  Created by mac on 2017/7/25.
//  Copyright © 2017年 UFA. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseTableView.h"
@interface ContentTableView : UITableView
@property (nonatomic, weak) id actionDelegate;
@end
