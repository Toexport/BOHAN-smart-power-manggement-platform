//
//  DeviceInfoCollectionCell.m
//  Bohan
//
//  Created by Yang Lin on 2018/5/13.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import "DeviceInfoCollectionCell.h"
#import "DebuggingANDPublishing.pch"
@implementation DeviceInfoCollectionCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

@end
