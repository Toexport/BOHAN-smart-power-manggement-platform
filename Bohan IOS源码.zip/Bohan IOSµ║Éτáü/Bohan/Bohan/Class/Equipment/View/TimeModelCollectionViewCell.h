//
//  TimeModelCollectionViewCell.h
//  Bohan
//
//  Created by Yang Lin on 2018/1/25.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TimeModelCollectionViewCell : UICollectionViewCell

@property (weak, nonatomic) IBOutlet UILabel *name;
@end
