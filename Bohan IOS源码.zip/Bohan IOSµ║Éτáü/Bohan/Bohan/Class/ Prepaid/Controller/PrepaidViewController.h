//
//  PrepaidViewController.h
//  Bohan
//
//  Created by summer on 2018/8/23.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import "BaseViewController.h"

@interface PrepaidViewController : BaseViewController

@end
