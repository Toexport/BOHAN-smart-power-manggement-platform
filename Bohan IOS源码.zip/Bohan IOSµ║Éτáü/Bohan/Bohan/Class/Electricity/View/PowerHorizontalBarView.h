//
//  PowerHorizontalBarView.h
//  Bohan
//
//  Created by Yang Lin on 2018/2/2.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PowerHorizontalBarView : UIView


@property (nonatomic, copy)NSArray *datas;
@property (nonatomic, copy)NSString *title;
@end
