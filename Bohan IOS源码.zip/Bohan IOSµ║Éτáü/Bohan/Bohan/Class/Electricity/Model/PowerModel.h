//
//  PowerModel.h
//  Bohan
//
//  Created by Yang Lin on 2018/2/2.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface PowerModel : NSObject

@property (nonatomic, copy) NSString *avgPowerData;
@property (nonatomic, copy) NSString *date;
@property (nonatomic, copy) NSString *powerData;

@end
