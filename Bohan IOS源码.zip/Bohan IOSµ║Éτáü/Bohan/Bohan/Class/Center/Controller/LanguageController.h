//
//  LanguageController.h
//  Bohan
//
//  Created by summer on 2018/7/11.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BaseViewController.h"
@interface LanguageController : BaseViewController
@property (weak, nonatomic) IBOutlet UITableView *tableview;

@end
