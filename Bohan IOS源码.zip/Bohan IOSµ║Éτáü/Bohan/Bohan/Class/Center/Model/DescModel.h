//
//  DescModel.h
//  Bohan
//
//  Created by Yang Lin on 2018/2/7.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface DescModel : NSObject

@property (nonatomic, copy) NSString * cID;
@property (nonatomic, copy) NSString * cDesc;

@end
