//
//  DeviceModel.m
//  Bohan
//
//  Created by Yang Lin on 2018/1/1.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import "DeviceModel.h"

@implementation DeviceModel

@end
