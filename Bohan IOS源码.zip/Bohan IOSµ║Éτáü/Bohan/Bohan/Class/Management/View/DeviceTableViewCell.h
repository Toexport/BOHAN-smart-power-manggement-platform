//
//  DeviceTableViewCell.h
//  Bohan
//
//  Created by Yang Lin on 2018/1/1.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import <UIKit/UIKit.h>
@class DeviceModel;
@interface DeviceTableViewCell : UITableViewCell

@property (nonatomic, strong)DeviceModel *model;
@end
