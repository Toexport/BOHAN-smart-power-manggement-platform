//
//  WifiConnectViewController.h
//  Bohan
//
//  Created by Yang Lin on 2018/1/9.
//  Copyright © 2018年 Bohan. All rights reserved.
//

#import "BaseViewController.h"

@interface WifiConnectViewController : BaseViewController

@property (nonatomic, copy)NSString *deviceNo;
@end
